/**************************/
/* Example 1: Magic Trick */
/**************************/


const magicButton = document.querySelector("#magic-button");
const bunny = document.querySelector("#bunny");

magicButton.addEventListener("click", () => {
    if (bunny.classList.contains("hidden")) {
        bunny.classList.remove("hidden");
    } else {
        bunny.classList.add("hidden");
    }
    // or just use this line!
    // bunny.classList.toggle("hidden");
})

/******************************************/
/*  Example 2: Traffic Lights (classList) */
/******************************************/


// 1. get all elements for this example (three lights, three buttons)
const goBtn = document.querySelector("#goBtn")
const stopBtn = document.querySelector("#stopBtn")
const slowBtn = document.querySelector("#slowBtn")
const go = document.querySelector("#go")
const slow = document.querySelector("#slow")
const stop = document.querySelector("#stop")

// 2. attach event listeners to each button
goBtn.addEventListener("click", () => {
    go.classList.add("green");
    stop.classList.remove("red");
    slow.classList.remove("yellow");
})

stopBtn.addEventListener("click", () => {
    stop.classList.add("red");
    go.classList.remove("green");
    slow.classList.remove("yellow");
})

slowBtn.addEventListener("click", () => {
    slow.classList.add("yellow");
    go.classList.remove("green");
    stop.classList.remove("red");
})

/*********************************************************************/
/* Example 3: Skill Checkboxes (forEach and creating Elements/Nodes) */
/*********************************************************************/

// grab all checkbox elements
const skills = document.querySelectorAll("input[type=checkbox]")

// grab button and list elements
const skillBtn = document.querySelector("#skillBtn")
const skillList = document.querySelector("#skill-list")


skillBtn.addEventListener("click", () => {
    // 1. clear list
    skillList.innerHTML = "";

    // 2. create an empty array, find each checked item and add it to the array
    let skillArray = [];
    skills.forEach(skill => {
        if (skill.checked) {
            skillArray.push(skill.name);
        }
    })

    // 3. create list of skills to display on page (adding nodes to the DOM)
    skillArray.forEach(skill => {
        const item = document.createElement("li");  // create li node
        const itemText = document.createTextNode(skill); // create text node
        item.appendChild(itemText); // add text node to li node
        skillList.appendChild(item) // add li to skill-list ul
    })
})
