"use strict";

const $ = selector => document.querySelector(selector);

