const $ = selector => document.querySelector(selector);

