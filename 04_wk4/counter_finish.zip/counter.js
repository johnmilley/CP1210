
// grab elements
const scoreLabel = document.querySelector("#score");
const downButton = document.querySelector("#score-down");
const upButton = document.querySelector("#score-up");

let score = parseInt(scoreLabel.innerText);

/* regular function (hoisted) */
// function scoreUp() {
//     score += 1;
//     scoreLabel.innerText = score;
// }

// function expressions as arrow functions (not hoisted)
const scoreUp = () => {
        score += 1;
        scoreLabel.innerText = score;
    }

const scoreDown = () => {
    if (score > 0) {
        score -= 1;
        scoreLabel.innerText = score;
    }
}

// downButton.disabled = true;

// attach event handlers to elements use 
// usage: element.addEventListener("event", functionExpression)
downButton.addEventListener("click", scoreDown);
upButton.addEventListener("click", scoreUp);
