// global variables
let timer = null;
let counter = 3;

const countLabel = document.querySelector("#count");

const countDown = () => {
    if (counter > 0) {
        countLabel.innerHTML = counter;
    } else {
        countLabel.innerHTML = "🚀";
        // cancel timer
        clearInterval(timer);
    }
    counter--;
}

countLabel.addEventListener("click", () => {
    counter = 3; //reset count on click
    // call countDown every 1000ms (=1sec)
    timer = setInterval(countDown, 1000); 
});