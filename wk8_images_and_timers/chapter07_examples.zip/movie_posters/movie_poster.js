/* Preloading images

1. grab links

const links = document.querySelectorAll("a");

2. loop through images, create Image object and assign the current image location to the src property of the Image objects (this preloads the image)

for (let link in links) {
    const image = new Image();
    image.src = link.src;
}

or

links.forEach(link ==> {
    (new Image()).src = link.href;
});


attributes of image elements: src, alt, width, height

*/




const imageGrid = document.querySelector("#image-container");
const poster = document.querySelector("#poster");

// get all images on page
const imgs = document.querySelectorAll("img");

// go through and preload each image
// and attach click event to each image
imgs.forEach(img => {
    (new Image()).src = img.src;

    img.addEventListener('click', (evt) => {
        imageGrid.classList.toggle("hide");
        poster.src = img.src;
        poster.classList.toggle("hide");
    })
})
