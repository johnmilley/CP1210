const $ = element => document.querySelector(element);

const intervalTimer = setInterval(flashingLights, 750);

setTimeout(stopFlashing, 10000);

/* these two functions are hoisted to the top of the
file on page load */
function flashingLights() {
    $("#stop").classList.toggle("red");
}

function stopFlashing() {
    clearInterval(intervalTimer);
}